-- SQL скрипт для створення таблиць бота SkillKlan
-- Використовується PostgreSQL

-- Таблиця користувачів бота
CREATE TABLE IF NOT EXISTS bot_users (
    id SERIAL PRIMARY KEY,
    telegram_id BIGINT UNIQUE NOT NULL,
    username VARCHAR(255),
    current_step VARCHAR(50) NOT NULL DEFAULT 'start',
    selected_profession VARCHAR(10),
    contact_data JSONB,
    task_sent BOOLEAN DEFAULT FALSE,
    task_sent_at TIMESTAMP,
    task_deadline TIMESTAMP,
    reminders_sent JSONB DEFAULT '[]',
    last_activity TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Таблиця контактів
CREATE TABLE IF NOT EXISTS bot_contacts (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES bot_users(id) ON DELETE CASCADE,
    phone_number VARCHAR(20) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id)
);

-- Таблиця доставки завдань
CREATE TABLE IF NOT EXISTS bot_task_deliveries (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES bot_users(id) ON DELETE CASCADE,
    profession VARCHAR(10) NOT NULL,
    task_title VARCHAR(255) NOT NULL,
    task_description TEXT,
    task_content TEXT,
    delivered_at TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Індекси для покращення продуктивності
CREATE INDEX IF NOT EXISTS idx_bot_users_telegram_id ON bot_users(telegram_id);
CREATE INDEX IF NOT EXISTS idx_bot_users_current_step ON bot_users(current_step);
CREATE INDEX IF NOT EXISTS idx_bot_users_task_sent ON bot_users(task_sent);
CREATE INDEX IF NOT EXISTS idx_bot_users_last_activity ON bot_users(last_activity);
CREATE INDEX IF NOT EXISTS idx_bot_contacts_user_id ON bot_contacts(user_id);
CREATE INDEX IF NOT EXISTS idx_bot_task_deliveries_user_id ON bot_task_deliveries(user_id);
CREATE INDEX IF NOT EXISTS idx_bot_task_deliveries_profession ON bot_task_deliveries(profession);
CREATE INDEX IF NOT EXISTS idx_bot_task_deliveries_delivered_at ON bot_task_deliveries(delivered_at);

-- Тригери для автоматичного оновлення updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Застосування тригерів до таблиць
DROP TRIGGER IF EXISTS update_bot_users_updated_at ON bot_users;
CREATE TRIGGER update_bot_users_updated_at
    BEFORE UPDATE ON bot_users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_bot_contacts_updated_at ON bot_contacts;
CREATE TRIGGER update_bot_contacts_updated_at
    BEFORE UPDATE ON bot_contacts
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_bot_task_deliveries_updated_at ON bot_task_deliveries;
CREATE TRIGGER update_bot_task_deliveries_updated_at
    BEFORE UPDATE ON bot_task_deliveries
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Коментарі до таблиць
COMMENT ON TABLE bot_users IS 'Користувачі бота з їх станом';
COMMENT ON TABLE bot_contacts IS 'Контактні дані користувачів';
COMMENT ON TABLE bot_task_deliveries IS 'Історія доставки тестових завдань';

-- Коментарі до колонок bot_users
COMMENT ON COLUMN bot_users.telegram_id IS 'Унікальний ID користувача в Telegram';
COMMENT ON COLUMN bot_users.username IS 'Username користувача в Telegram';
COMMENT ON COLUMN bot_users.current_step IS 'Поточний крок в флоу бота';
COMMENT ON COLUMN bot_users.selected_profession IS 'Вибрана професія (QA або BA)';
COMMENT ON COLUMN bot_users.contact_data IS 'Контактні дані в JSON форматі';
COMMENT ON COLUMN bot_users.task_sent IS 'Чи відправлено тестове завдання';
COMMENT ON COLUMN bot_users.task_sent_at IS 'Коли було відправлено завдання';
COMMENT ON COLUMN bot_users.task_deadline IS 'Дедлайн виконання завдання';
COMMENT ON COLUMN bot_users.reminders_sent IS 'Масив відправлених нагадувань в JSON форматі';
COMMENT ON COLUMN bot_users.last_activity IS 'Остання активність користувача';
